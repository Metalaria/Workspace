package Ejercicio1;
public interface Ordenable {
	public boolean esMayor (Ordenable o);
	public boolean esMenor (Ordenable o);
}
