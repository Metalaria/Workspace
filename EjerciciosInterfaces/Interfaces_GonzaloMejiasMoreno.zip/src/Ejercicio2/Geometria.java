package Ejercicio2;

public interface Geometria {
	public double calcularArea();
	public double calcularPerimetro();
}
