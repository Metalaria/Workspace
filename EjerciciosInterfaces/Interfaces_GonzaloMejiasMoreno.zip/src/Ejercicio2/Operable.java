package Ejercicio2;

public interface Operable {

		/*-	void sumar(Operable op)
		-	void multiplicar(Operable op)
		-	void restar(Operable op)*/
		public void sumar(Operable op);
		public void multiplicar(Operable op);
		public void restar(Operable op);




}
