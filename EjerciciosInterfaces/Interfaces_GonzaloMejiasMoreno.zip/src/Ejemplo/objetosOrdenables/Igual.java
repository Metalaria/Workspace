package Ejemplo.objetosOrdenables;

public interface Igual extends Ordenable {

}
